package com.example.chatapp;

  /**
     * cellphone check: use regex that ensures an international code prefix (e.g. +27)
     * followed by the national number. For this POE we accept:
     *    - South Africa mobile format: +27 followed by 9 digits -> ^\+27\d{9}$
     * That will match your test input ‪+27838968976‬.
     *
     * Attribution: The regex and validation approach below were crafted with assistance
     * from an AI tool OpenAI. (2025).ChatGPT [Large Language model]. hhtps://chat.openai.com/
     */

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.HashMap;
import javax.swing.border.Border;

public class ChatApp1 {

    // --------- User Class ---------
    static class User {
        private String fullname, gender, username, password, phone, profileImagePath;

        public User(String fullname, String gender, String username,
                    String password, String phone, String profileImagePath) {
            this.fullname = fullname;
            this.gender = gender;
            this.username = username;
            this.password = password;
            this.phone = phone;
            this.profileImagePath = profileImagePath;
        }

        public String getFullname() { return fullname; }
        public String getGender() { return gender; }
        public String getUsername() { return username; }
        public String getPassword() { return password; }
        public String getPhone() { return phone; }
        public String getProfileImagePath() { return profileImagePath; }
    }

    // --------- Login Logic ---------
    static class Login {
        protected static HashMap<String, User> users = new HashMap<>();

        public boolean checkUsername(String username) {
            return username.contains("_") && username.length() <= 5;
        }

        public boolean checkPasswordComplexity(String password) {
            return password != null && password.length() > 8;
        }

        public boolean checkCellphone(String phone) {
            return phone != null && phone.matches("^\\+27\\d{9}$");
        }

        public String registerUser(String fullname, String gender, String username,
                                   String password, String confirmPassword,
                                   String phone, String imagePath) {

            // Collect missing fields
            StringBuilder missingFields = new StringBuilder();

            if (fullname == null || fullname.isEmpty()) missingFields.append("Full Name, ");
            if (username == null || username.isEmpty()) missingFields.append("Username, ");
            if (phone == null || phone.isEmpty()) missingFields.append("Phone Number, ");
            if (password == null || password.isEmpty()) missingFields.append("Password, ");
            if (confirmPassword == null || confirmPassword.isEmpty()) missingFields.append("Confirm Password, ");
            if (gender == null || gender.isEmpty()) missingFields.append("Gender, ");

            // If any fields are missing
            if (missingFields.length() > 0) {
                String fields = missingFields.substring(0, missingFields.length() - 2);
                if (fields.contains(",")) {
                    return "Please fill in the following fields: " + fields + ".";
                } else {
                    return "Please fill in the " + fields + ".";
                }
            }

            // Username validation
            if (!checkUsername(username)) {
                return "Username must contain an underscore and be no longer than 5 characters.";
            }

            // Password validation (still just length > 8)
            if (!checkPasswordComplexity(password)) {
                return "Password must be at least 8 characters long and include letters.";
            }

            // Cellphone validation
            if (!checkCellphone(phone)) {
                return "Phone number must start with +27 followed by 9 digits (example: +27831234567).";
            }

            // Password match check
            if (!password.equals(confirmPassword)) {
                return "Passwords do not match. Please re-enter your password.";
            }

            // Duplicate username check
            if (users.containsKey(username)) {
                return "This username is already taken. Please choose a different one.";
            }

            // ✅ Success
            User user = new User(fullname, gender, username, password, phone, imagePath);
            users.put(username, user);
            return "Registration successful!";
        }

        public boolean loginUser(String username, String password) {
            User user = users.get(username);
            return user != null && user.getPassword().equals(password);
        }

        public String returnLoginStatus(boolean loginSuccess, String username) {
            if (loginSuccess) {
                return "Welcome " + username + ", it is great to see you again.";
            }
            return "Username or password incorrect, please try again.";
        }
    }

    // --------- Registration Form ---------
    static class RegisterForm {
        private JFrame frame;
        private JTextField fullnameField, usernameField, phoneField;
        private JPasswordField passwordField, confirmpasswordField;
        private JRadioButton maleRadioButton, femaleRadioButton;
        private ButtonGroup genderGroup;
        private JLabel profilePictureImage;
        private JButton browseButton, buttonRegister, returnToLoginButton;
        private String selectedImagePath;

        public RegisterForm() {
            frame = new JFrame("Register Form");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(500, 750);
            frame.setLocationRelativeTo(null);

            JPanel contentPanel = new JPanel(new GridBagLayout());
            contentPanel.setBackground(Color.BLACK);
            contentPanel.setBorder(BorderFactory.createLineBorder(Color.BLUE, 5));

            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(10, 10, 10, 10);
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.anchor = GridBagConstraints.WEST;

            // Full Name
            gbc.gridx = 0; gbc.gridy = 0;
            contentPanel.add(new JLabel("Full Name") {{ setForeground(Color.BLUE); }}, gbc);
            gbc.gridx = 1;
            fullnameField = new JTextField(15);
            contentPanel.add(fullnameField, gbc);

            // Username
            gbc.gridx = 0; gbc.gridy++;
            contentPanel.add(new JLabel("Username") {{ setForeground(Color.BLUE); }}, gbc);
            gbc.gridx = 1;
            usernameField = new JTextField(15);
            contentPanel.add(usernameField, gbc);

            // Phone
            gbc.gridx = 0; gbc.gridy++;
            contentPanel.add(new JLabel("Phone") {{ setForeground(Color.BLUE); }}, gbc);
            gbc.gridx = 1;
            phoneField = new JTextField(15);
            contentPanel.add(phoneField, gbc);

            // Password
            gbc.gridx = 0; gbc.gridy++;
            contentPanel.add(new JLabel("Password") {{ setForeground(Color.BLUE); }}, gbc);
            gbc.gridx = 1;
            passwordField = new JPasswordField(15);
            contentPanel.add(passwordField, gbc);

            // Show password checkbox
            gbc.gridx = 1; gbc.gridy++;
            JCheckBox showPasswordCheck = new JCheckBox("Show");
            showPasswordCheck.setForeground(Color.BLUE);
            showPasswordCheck.setBackground(Color.BLACK);
            contentPanel.add(showPasswordCheck, gbc);
            showPasswordCheck.addActionListener(e -> 
                passwordField.setEchoChar(showPasswordCheck.isSelected() ? (char)0 : '•')
            );

            // Confirm Password
            gbc.gridx = 0; gbc.gridy++;
            contentPanel.add(new JLabel("Confirm Password") {{ setForeground(Color.BLUE); }}, gbc);
            gbc.gridx = 1;
            confirmpasswordField = new JPasswordField(15);
            contentPanel.add(confirmpasswordField, gbc);

            // Show confirm password checkbox
            gbc.gridx = 1; gbc.gridy++;
            JCheckBox showConfirmPasswordCheck = new JCheckBox("Show");
            showConfirmPasswordCheck.setForeground(Color.BLUE);
            showConfirmPasswordCheck.setBackground(Color.BLACK);
            contentPanel.add(showConfirmPasswordCheck, gbc);
            showConfirmPasswordCheck.addActionListener(e ->
                confirmpasswordField.setEchoChar(showConfirmPasswordCheck.isSelected() ? (char)0 : '•')
            );

            // Gender
            gbc.gridx = 0; gbc.gridy++;
            contentPanel.add(new JLabel("Gender") {{ setForeground(Color.BLUE); }}, gbc);
            gbc.gridx = 1;
            JPanel genderPanel = new JPanel();
            genderPanel.setBackground(Color.BLACK);
            maleRadioButton = new JRadioButton("Male"); maleRadioButton.setForeground(Color.BLUE); maleRadioButton.setBackground(Color.BLACK);
            femaleRadioButton = new JRadioButton("Female"); femaleRadioButton.setForeground(Color.BLUE); femaleRadioButton.setBackground(Color.BLACK);
            genderGroup = new ButtonGroup();
            genderGroup.add(maleRadioButton); genderGroup.add(femaleRadioButton);
            genderPanel.add(maleRadioButton); genderPanel.add(femaleRadioButton);
            contentPanel.add(genderPanel, gbc);

            // Profile Picture
            gbc.gridx = 0; gbc.gridy++;
            contentPanel.add(new JLabel("Profile Picture") {{ setForeground(Color.BLUE); }}, gbc);
            gbc.gridx = 1;
            profilePictureImage = new JLabel();
            profilePictureImage.setPreferredSize(new Dimension(120, 120));
            Border border = BorderFactory.createLineBorder(Color.BLUE, 2);
            profilePictureImage.setBorder(border);
            contentPanel.add(profilePictureImage, gbc);

            gbc.gridy++;
            browseButton = new JButton("Browse");
            contentPanel.add(browseButton, gbc);
            browseButton.addActionListener(e -> {
                JFileChooser fileChooser = new JFileChooser();
                if (fileChooser.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION) {
                    File file = fileChooser.getSelectedFile();
                    selectedImagePath = file.getAbsolutePath();
                    ImageIcon icon = new ImageIcon(new ImageIcon(selectedImagePath).getImage()
                            .getScaledInstance(profilePictureImage.getWidth(), profilePictureImage.getHeight(), Image.SCALE_SMOOTH));
                    profilePictureImage.setIcon(icon);
                }
            });

            // Register button
            gbc.gridx = 0; gbc.gridy++; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
            buttonRegister = new JButton("Register");
            contentPanel.add(buttonRegister, gbc);

            // Return to Login button
            returnToLoginButton = new JButton("Return");
            returnToLoginButton.addActionListener(e -> {
                frame.setVisible(false);
                new LoginForm(); // Show login form
            });
            contentPanel.add(returnToLoginButton, gbc);

            Login loginLogic = new Login();
            buttonRegister.addActionListener(e -> {
                String fullname = fullnameField.getText().trim();
                String username = usernameField.getText().trim();
                String password = new String(passwordField.getPassword());
                String confirmPassword = new String(confirmpasswordField.getPassword());
                String phone = phoneField.getText().trim();
                String gender = maleRadioButton.isSelected() ? "Male" : femaleRadioButton.isSelected() ? "Female" : "";

                String registrationMessage = loginLogic.registerUser(
                        fullname, gender, username, password, confirmPassword, phone, selectedImagePath
                );

                JOptionPane.showMessageDialog(frame, registrationMessage);
                if (registrationMessage.equals("Registration successful!")) {
                    frame.setVisible(false); // Close the registration form
                    new LoginForm(); // Open login page
                }
            });

            frame.add(contentPanel);
            frame.setVisible(true);
        }
    }

    // --------- Login Form (styled) ---------
    static class LoginForm {
        private JFrame frame;
        private JTextField usernameField;
        private JPasswordField passwordField;
        private JButton loginButton, registerButton;

        public LoginForm() {
            frame = new JFrame("Login");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(450, 400);
            frame.setLocationRelativeTo(null);

            JPanel contentPanel = new JPanel(new GridBagLayout());
            contentPanel.setBackground(Color.BLACK);
            contentPanel.setBorder(BorderFactory.createLineBorder(Color.BLUE, 5));

            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(10, 10, 10, 10);
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.anchor = GridBagConstraints.WEST;

            // Username
            gbc.gridx = 0; gbc.gridy = 0;
            contentPanel.add(new JLabel("Username") {{ setForeground(Color.BLUE); }}, gbc);
            gbc.gridx = 1;
            usernameField = new JTextField(15);
            contentPanel.add(usernameField, gbc);

            // Password
            gbc.gridx = 0; gbc.gridy++;
            contentPanel.add(new JLabel("Password") {{ setForeground(Color.BLUE); }}, gbc);
            gbc.gridx = 1;
            passwordField = new JPasswordField(15);
            contentPanel.add(passwordField, gbc);

            // Show password checkbox
            gbc.gridx = 1; gbc.gridy++;
            JCheckBox showPasswordCheck = new JCheckBox("Show");
            showPasswordCheck.setForeground(Color.BLUE);
            showPasswordCheck.setBackground(Color.BLACK);
            contentPanel.add(showPasswordCheck, gbc);
            showPasswordCheck.addActionListener(e -> 
                passwordField.setEchoChar(showPasswordCheck.isSelected() ? (char)0 : '•')
            );

            // Login button
            gbc.gridx = 0; gbc.gridy++; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
            loginButton = new JButton("Login");
            contentPanel.add(loginButton, gbc);

            // Register button (link to registration)
            gbc.gridy++;
            registerButton = new JButton("Register");
            registerButton.setForeground(Color.BLUE);
            registerButton.setBackground(Color.WHITE);
            contentPanel.add(registerButton, gbc);

            Login loginLogic = new Login();
            loginButton.addActionListener(e -> {
                String username = usernameField.getText().trim();
                String password = new String(passwordField.getPassword());
                boolean loginSuccess = loginLogic.loginUser(username, password);
                String message = loginLogic.returnLoginStatus(loginSuccess, username);
                JOptionPane.showMessageDialog(frame, message);
                if (loginSuccess) {
                    frame.setVisible(false);
                    new HomePage(username);
                }
            });

            registerButton.addActionListener(e -> {
                frame.setVisible(false);
                new RegisterForm(); // Open register form
            });

            frame.add(contentPanel);
            frame.setVisible(true);
        }
    }

    // --------- Home Page ---------
    static class HomePage {
        private JFrame frame;
        private JLabel usernameLabel, fullnameLabel, genderLabel, phoneLabel, profilePicLabel;

        public HomePage(String username) {
            frame = new JFrame("Home Page");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(500, 500);
            frame.setLocationRelativeTo(null);

            JPanel contentPanel = new JPanel();
            contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
            contentPanel.setBackground(Color.BLACK);

            // User details display
            Login loginLogic = new Login();
            User user = loginLogic.users.get(username);

            profilePicLabel = new JLabel();
            ImageIcon profilePic = new ImageIcon(new ImageIcon(user.getProfileImagePath()).getImage()
                    .getScaledInstance(100, 100, Image.SCALE_SMOOTH));
            profilePicLabel.setIcon(profilePic);
            contentPanel.add(profilePicLabel);

            usernameLabel = new JLabel("Username: " + user.getUsername());
            usernameLabel.setForeground(Color.WHITE);
            fullnameLabel = new JLabel("Full Name: " + user.getFullname());
            fullnameLabel.setForeground(Color.WHITE);
            genderLabel = new JLabel("Gender: " + user.getGender());
            genderLabel.setForeground(Color.WHITE);
            phoneLabel = new JLabel("Phone: " + user.getPhone());
            phoneLabel.setForeground(Color.WHITE);

            contentPanel.add(usernameLabel);
            contentPanel.add(fullnameLabel);
            contentPanel.add(genderLabel);
            contentPanel.add(phoneLabel);

            frame.add(contentPanel);
            frame.setVisible(true);
        }
    }

    public static void main(String[] args) {
        new LoginForm(); // Show the login form initially
    }
}

    
